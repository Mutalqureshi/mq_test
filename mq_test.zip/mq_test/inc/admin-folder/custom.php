<?php
/*
     *
     * ---> START SECTIONS
     *
     */
	Redux::setSection( $opt_name, array(
		'title' => __('Logo/Icon/Slider', 'redux-framework-demo'),

		'fields' => array (
			array(
				'id'       => 'site-logo',
				'type'     => 'media',
				'url'      => true,
				'title'    => __( 'Header Logo', 'redux-framework-demo' ),
			),

			array(
				'id'       => 'site-logo-sticky',
				'type'     => 'media',
				'url'      => true,
				'title'    => __( 'Sticky Header Logo', 'redux-framework-demo' ),
			),
			
			array(
				'id'       => 'login-logo',
				'type'     => 'media',
				'url'      => true,
				'title'    => __( 'Login Page Logo', 'redux-framework-demo' ),
			),
    
			array(
				'id'       => 'favicon-logo',
				'type'     => 'media',
				'title'    => __( 'Favicon', 'redux-framework-demo' ),
				'preview' => false,
			),
			// array(
			//     'id' => 'logo-gallery',
			//     'type'     => 'gallery',
			//     'title'    => __('Add/Edit Gallery', 'redux-framework-demo'),
			//     'url'      => true,
			//     'subtitle' => __('Create a new Gallery by selecting existing or uploading new images using the WordPress native uploader', 'redux-framework-demo'),
			//     'desc' => __('This is the description field, again good for additional info.', 'redux-framework-demo'),
			//   ),				
			array (
				'desc' => __('Book A Charter TEXT', 'redux-framework-demo'),
				'id' => 'header_text',
				'type' => 'text',
				'title' => __('Book A Charter TEXT', 'redux-framework-demo'),
			),
		),
		//'icon' => 'el-icon-home',
	) );
	
	
	Redux::setSection( $opt_name, array(
		'title' => __('Social Media Links', 'redux-framework-demo'),
		'fields' => array (		
			array (
				'desc' => __('Enter Facebook Link.', 'redux-framework-demo'),
				'id' => 'facebook',
				'type' => 'text',
				'title' => __('Facebook', 'redux-framework-demo'),
				'validate' => 'url',
			),
			array (
				'desc' => __('Enter Twitter Link.', 'redux-framework-demo'),
				'id' => 'twitter',
				'type' => 'text',
				'title' => __('Twitter', 'redux-framework-demo'),
				'validate' => 'url',
			),
			array (
				'desc' => __('Enter Linkedin Link.', 'redux-framework-demo'),
				'id' => 'linkedin',
				'type' => 'text',
				'title' => __('Linkedin', 'redux-framework-demo'),
				'validate' => 'url',
			),
			array (
				'desc' => __('Enter TikTok Link.', 'redux-framework-demo'),
				'id' => 'TikTok',
				'type' => 'text',
				'title' => __('TikTok', 'redux-framework-demo'),
				'validate' => 'url',
			),
			array (
				'desc' => __('Enter Instagram Link.', 'redux-framework-demo'),
				'id' => 'instagram',
				'type' => 'text',
				'title' => __('Instagram', 'redux-framework-demo'),
				'validate' => 'url',
			),
			array (
				'desc' => __('Enter YouTube Link.', 'redux-framework-demo'),
				'id' => 'youtube',
				'type' => 'text',
				'title' => __('YouTube', 'redux-framework-demo'),
				'validate' => 'url',
			),
			array (
				'desc' => __('Enter SnapChat Link.', 'redux-framework-demo'),
				'id' => 'SnapChat',
				'type' => 'text',
				'title' => __('SnapChat', 'redux-framework-demo'),
				'validate' => 'url',
			),						
			
		),
		'icon' => 'el-icon-network',
	) );
	
	
	/* Contact */
	Redux::setSection( $opt_name, array(
		'title' => __('Contact', 'redux-framework-demo'),
		'fields' => array (
			array (
				'id' => 'address_heading',
				'type' => 'text',
				'title' => __('HeadQuarter Footer Text', 'redux-framework-demo'),
				'rows'    => '2'
			),	

			array (
				'id' => 'address',
				'type' => 'textarea',
				'title' => __('Address', 'redux-framework-demo'),
				// 'rows'    => '2'
			),
			array (
				'id' => 'phone',
				'type' => 'text',
				'title' => __('Contact Number', 'redux-framework-demo'),
				'label'    => true,
			),
			/*array (
				'id' => 'fax',
				'type' => 'text',
				'title' => __('Fax Number', 'redux-framework-demo'),
				'label'    => true,
			),*/
			array (
				'id' => 'email',
				'type' => 'text',
				'title' => __('Contact Email', 'redux-framework-demo'),
			),
			

		),
		'icon' => 'el-icon-map-marker',
    ) );
	
	
	
	
	
	Redux::setSection( $opt_name, array(
		'icon'      => 'el-icon-cogs',
		'title'     => __('General Settings', 'redux-framework-demo'),
		'fields'    => array(



			array(
				'id'        => 'homepage-content',
				'type'      => 'editor',
				'title'     => __('Homepage Text', 'redux-framework-demo'),
				'args'   => array(
					//'teeny'            => true,
					'wpautop'       => true,
					'media_buttons'    => true,
					'textarea_rows'    => 5
				),
				//'default'   => 'Powered by Redux Framework.',
			),
			array(
				'id'        => 'restrcited-content',
				'type'      => 'editor',
				'title'     => __('Restrcited Text', 'redux-framework-demo'),
				'args'   => array(
					//'teeny'            => true,
					'media_buttons'    => false,
					'textarea_rows'    => 3
				),
				//'default'   => 'Powered by Redux Framework.',
			),
			array(
				'id'        => 'subscription_cancel_notice-content',
				'type'      => 'editor',
				'title'     => __('Subscription Cancel Notice', 'redux-framework-demo'),
				'args'   => array(
					//'teeny'            => true,
					'media_buttons'    => false,
					'textarea_rows'    => 2
				),
				//'default'   => 'Powered by Redux Framework.',
			),
			array(
				'id'        => 'opt-ace-editor-css',
				'type'      => 'ace_editor',
				'title'     => __('CSS Code', 'redux-framework-demo'),
				'subtitle'  => __('Paste your custom CSS code here. Priority is header.', 'redux-framework-demo'),
				'mode'      => 'css',
				'theme'     => 'monokai',
				//'desc'      => 'Possible modes can be found at <a href="http://ace.c9.io" target="_blank">http://ace.c9.io/</a>.',
				//'default'   => "#header{\nmargin: 0 auto;\n}"
			),
			array(
				'id'        => 'opt-ace-editor-js',
				'type'      => 'ace_editor',
				'title'     => __('JS Code', 'redux-framework-demo'),
				'subtitle'  => __('Paste your custom JS code here. Priority is footer.', 'redux-framework-demo'),
				'mode'      => 'javascript',
				'theme'     => 'chrome',
				//'desc'      => 'Possible modes can be found at <a href="http://ace.c9.io" target="_blank">http://ace.c9.io/</a>.',
				//'default'   => "jQuery(document).ready(function(){\n\n});"
			),

			array(
				'id'        => 'footer-copyright',
				'type'      => 'editor',
				'title'     => __('Footer Text', 'redux-framework-demo'),
				'subtitle'  => __('You can use the following shortcodes in your footer text: [wp-url] [site-url] [theme-url] [login-url] [logout-url] [site-title] [site-tagline] [current-year]', 'redux-framework-demo'),
				'args'   => array(
					//'teeny'            => true,
					'media_buttons'    => false,
					'textarea_rows'    => 3
				),
				//'default'   => 'Powered by Redux Framework.',
			),
		)
    ) );
	
	
	
	
	
	
	
	
	
	Redux::setSection( $opt_name, array(
		'icon'      => 'el-icon-fontsize',
		'title'     => __('Font / Typography', 'redux-framework-demo'),
		'fields'    => array(


			array(
                'id'       => 'opt-typography-body',
                'type'     => 'typography',
                'title'    => __( 'Body Font', 'redux-framework-demo' ),
                'subtitle' => __( 'Specify the body font properties.', 'redux-framework-demo' ),
                'google'   => true,
				'font-backup' => true,
				'output'      => array( 'body' ),
				'text-align' => false,
                'default'  => array(
                    'color'       => '#000000',
                    'font-size'   => '15px',
                    'font-family' => 'Roboto,Arial,Helvetica,sans-serif',
					'google'      => true,
                    'font-weight' => '400',
					'line-height' => '40',
					'font-style'  => 'normal',
                ),
            ),
			array(
                'id'       => 'opt-typography-headings',
                'type'     => 'typography',
                'title'    => __( 'Headings Font', 'redux-framework-demo' ),
                'subtitle' => __( 'Specify the heading font properties.', 'redux-framework-demo' ),
                'google'   => true,
				'font-backup' => true,
				'output'      => array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6' ),
				'text-align' => false,
				'font-size' => false,
				'font-style' => false,
				'line-height' => false,
                'default'  => array(
                    'color'       => '#ff6b56',
                    //'font-size'   => '15px',
                    'font-family' => 'Roboto,Arial,Helvetica,sans-serif',
					'google'      => true,
                    'font-weight' => '500',
					//'line-height' => '40',
					//'font-style'  => 'normal',
                ),
            ),
		)
    ) );
	

    /*
     * <--- END SECTIONS
     */









